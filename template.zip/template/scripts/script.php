<?php

while (!feof(STDIN))
{
	$line = rtrim(fgets(STDIN));
}

?>
